

class buyer:
    def add_buyer(self,name,):
        pass
    def delet_buyer(self,name):
        pass
    def  display_all_buyers(self):
        pass
    def payment_history(slef):
        pass
    def credit(self):
        pass
    def debit(self):
        pass
    def  check_balance(self):
        pass
    def  search_by_name(self, mobile):
        pass
    