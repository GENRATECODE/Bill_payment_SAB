from flet import (
    UserControl,
    Column,
    Container,
    IconButton,
    Row,
    Text,
    IconButton,
    NavigationRail,
    NavigationRailDestination,
    TextField,
    alignment,
    border_radius,
    colors,
    icons,
    padding,
    margin,
)
import flet as ft
class Sidebar(Container):
    def __init__(self,app_layout,page,*args,**kwargs):
        super().__init__()
        self.page=page
        self.page.on_resized=self.on_resized
        self.app_layout = app_layout
        self.nav_rail_visible = True
        self.top_nav_items =[
                        NavigationRailDestination(
                label_content=Text("Dashboard"),
                label="Dashboard",
                icon=icons.TEXT_SNIPPET_OUTLINED,
                selected_icon=icons.TEXT_SNIPPET_OUTLINED,
                
            ),
               NavigationRailDestination(
                label_content=Text("Invoice"),
                label="Invoice",
                icon=icons.TEXT_SNIPPET_OUTLINED,
                selected_icon=icons.TEXT_SNIPPET_OUTLINED,
                
            ),
            NavigationRailDestination(
                label_content=Text("Stock Management"),
                label="Stock Management",             
                icon=icons.FORMAT_LIST_BULLETED_ADD,
                selected_icon=icons.FORMAT_LIST_BULLETED_ADD
            ), 

            NavigationRailDestination(
                label_content=Text("Stock Detail"),
                label="Stock Detail",
                icon=icons.PRICE_CHANGE_OUTLINED,
                selected_icon=icons.PRICE_CHANGE_OUTLINED
            ), 
            NavigationRailDestination(
                label_content=Text("Transport Detail"),
                label="Transport Detail",
                icon=icons.RESTORE_PAGE,
                selected_icon=icons.RESTORE_PAGE
            ),
            NavigationRailDestination(
                label_content=Text("Dealer Detail"),
                label="Dealer Detail",
                icon=icons.BOOK_OUTLINED,
                selected_icon=icons.BOOK_OUTLINED
            ), 
            NavigationRailDestination(
                label_content=Text("SubDealer Detail"),
                label="SubDealer Detail",
                icon=icons.PERSON,
                selected_icon=icons.PERSON
            ), 
            NavigationRailDestination(
                label_content=Text("Daily Spend"),
                label="Daily Spend",
                icon=icons.PERSON,
                selected_icon=icons.PERSON
            ),
            
            NavigationRailDestination(
                label_content=Text("Payment Det"),
                label="Employ Spend",
                icon=icons.PERSON,
                selected_icon=icons.PERSON
            ),

        ]
        self.top_nav_rail = NavigationRail(
            selected_index=None,
            label_type=ft.NavigationRailLabelType.SELECTED,
            on_change=self.top_nav_change,
            destinations=self.top_nav_items,
            bgcolor=colors.BLUE,
            extended=True,
            height=self.page.window_height*80/100  
        ) 
        self.bottom_nav_Item=[Row(controls=[ft.ElevatedButton("<<<<")])]
        self.bottom_nav_rail = NavigationRail(
            height=self.page.window_height*15/100,
            selected_index=None,
            label_type=ft.NavigationRailLabelType.SELECTED,
            on_change=self.bottom_nav_change,
            extended=True,
            expand=True,
            destinations=self.bottom_nav_Item,
            bgcolor=colors.GREY,
        )
        self.content_sidebar=Column([
                Row([
                    Text("Workspace",size=18),
                ], alignment="center"), 

                self.top_nav_rail,

                self.bottom_nav_rail
            ], tight=True)
        self.content=self.content_sidebar
        self.padding=padding.all(15)
        self.margin=margin.all(0)
        self.width=self.page.window_width
        self.height=self.page.window_height
        self.expand=1
        self.bgcolor="red"
        self.visible=self.nav_rail_visible
        self.offset=ft.transform.Offset(0,0)
        self.animate_offset=ft.animation.Animation(500)
        # self.col={"sm": 6, "md": 4, "xl": 2}
    def top_nav_change(self, e):
        # on_click=lambda _:self.page.go("/invoice")
        if int(e.control.selected_index)==0:
            self.page.go("/invoice")
            self.page.update()
        elif int(e.control.selected_index)==1:
            self.page.go("/item")
            self.page.update()
        elif int(e.control.selected_index)==2:
            self.page.go("/item")
            self.page.update()
        elif int(e.control.selected_index)==3:
            self.page.go("/item")
            self.page.update()
        elif int(e.control.selected_index)==4:
            self.page.go("/item")
            self.page.update()
        elif int(e.control.selected_index)==5:
            self.page.go("/item")
            self.page.update()        
        elif int(e.control.selected_index)==6:
            self.page.go("/item")
            self.page.update()        
        elif int(e.control.selected_index)==7:
            self.page.go("/item")
            self.page.update()
        else:
            print(f"{e},{e.control.selected_index}")
            print(f"Unexpected argument type in bottom_nav_change: {type(e)}")
    def bottom_nav_change(self, e):
        if isinstance(e, int):
            self.top_nav_rail.selected_index = None
            self.bottom_nav_rail.selected_index = e
        else:
            print(f"Unexpected argument type in bottom_nav_change: {type(e)}")
    def on_resized(self,e):
        self.width=self.page.window_width*20/100
        self.height=self.page.window_height
        self.top_nav_rail.height=self.page.window_height*80/100 - 100
        self.bottom_nav_rail=self.page.window_height*10/100
        self.view = self.page.window_width*30/100
        self.page.update() 
