
class buyyer:
    def __init__(self):
        pass
    def add_buyyer(self):
        pass
    def  show_all_buyers(self):
        pass
    def remove_buyyer(self):
        pass
    def search_buyyer(self,id):
        pass
    def credit(self):
        pass
    def debit(sef):
        pass
    def  check_balance(self):
        pass
    def update(self):
        pass