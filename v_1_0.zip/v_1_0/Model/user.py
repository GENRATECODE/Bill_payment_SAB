

class user:
    def __init__(self, name):
        pass
    def sign():
        pass
    def delete_user():
        pass
    def  forgot_user():
        pass
    def forgot_password():
        pass
    def display_users():
        pass
    def  search_user():
        pass
    
    def  log_in(self,username,password):
        pass

if __name__== "__main__":
    use_log=user()
    user_log
