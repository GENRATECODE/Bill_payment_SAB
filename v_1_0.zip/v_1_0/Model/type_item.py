items_type={
    "Standard Cycle 22":"CYSTD22",
    "Gents Cycle 20in":"CYG20",
    "Ladies Cycle 20in":"CYLD20",
    "Gents Cycle 18in":"CYG18",
    "Ladies Cycle 18in":"CYL18",
    "Ranger Cycle 26":"CYRG26",
    "Ranger Cycle 24":"CYRG24",
    "Cycle Parts":"PTCY",
    "Cycle Tyre":"CTY",
    "Cycle Tube":"CTB",
    "Auto Tyre":"ATY",
    "Auto Tube":"ATB",
    "Mobil":"MB",
    "Baby Cycle":"BCY",
    "Kid Cycle":"KCY"
}