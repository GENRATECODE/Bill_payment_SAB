


class custmer:
    def __init__(self):
        pass
    def add(self):
        pass
    def  remove(self,item):
        pass
    def cust_fetch(self):
        pass
    def modify(self):
        pass
    def  search(self):
        pass
    def credit(self):
        pass
    def debit(sef):
        pass
    def  check_balance(self):
        pass
    def update(self):
        pass
    
if __name__ =="__main__":
    product=item()
    