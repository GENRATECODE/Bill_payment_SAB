import flet as ft

from flet import (
    AlertDialog,
    AppBar,
    Column,
    Container,
    ElevatedButton,
    Icon,
    Page,
    PopupMenuButton, 
    PopupMenuItem,
    RoundedRectangleBorder,
    Row,
    TemplateRoute,
    Text,
    TextField,
    UserControl,
    View,
    colors,
    icons,
    margin,
    padding,
    theme)
from View.logo import raj_distributor
# all Page import in there 

# from View.app_bar import NavBar_for
from View.layout_app import AppLayout
from View.log_in_class import LoginPage
from View.sidebar import Sidebar
from View.home_page import HomePage 
# from View.dashboard import Dashboard


class ShopMangement(ft.UserControl):
    def __init__(self, page: Page):
        super().__init__()
        self.page = page
        self.page.on_route_change = self.route_change  # Assign the route change handler
        self.page.padding=0

        # Page LISt 


        # self.layout=AppLayout(page)
        # Initialize the app to navigate to the current route
        self.page.go(self.page.route)
    
    def route_change(self, route):
        # Clear current views before adding new one
        # self.page.views.clear()  
        if self.page and self.page.views:
            self.page.views.clear()
            print("condition check")
        # Determine which view to display based on the current route
        if self.page.route == "/":
            login_page = LoginPage(self.page)
            self.page.views.append(
                ft.View(
                    "/",
                    controls=[login_page.body,
                    ],padding=0,
                )
            )
        elif self.page.route == "/Home":
  # Ensure `home.build` returns a valid control
            self.layout=AppLayout(self,self.page,page_name="Home")
             # Switch to HomePage view
            self.page.views.append(
                ft.View(
                    "/Home",
                    appbar=self.layout.appbarpage,
                    controls=[
                       self.layout,
                        # ft.Text("Home Page"),
                        # ft.ElevatedButton("Go to Log Out", on_click=lambda _: self.page.go("/")),
                        # ft.ElevatedButton("Invoice", on_click=lambda _: self.page.go("/Invoice")),
                        # ft.ElevatedButton("Invoice Wholesale", on_click=lambda _: self.page.go("/Invoice_wholesale")),
                        # ft.ElevatedButton("Item_management", on_click=lambda _: self.page.go("/Item_Management")),
                        # ft.ElevatedButton("Cust_Management", on_click=lambda _: self.page.go("/Cust_Management")),
                        # ft.ElevatedButton("Transport_Detail", on_click=lambda _: self.page.go("/Transport_Detail")),
                        # ft.ElevatedButton("Vendor_Management", on_click=lambda _: self.page.go("/Vendor_Management")),
                    ],padding=0,
                )
            )
        elif self.page.route == "/Invoice":
            self.layout=AppLayout(self,self.page,page_name="B2C")
            self.page.views.append(
                ft.View(
                    "/Invoice",
                    appbar=self.layout.appbarpage,
                    controls=[
                       
                        ft.Text("Invoice Page"),
                        ft.ElevatedButton("Go to Log Out", on_click=lambda _: self.page.go("/")),
                        ft.ElevatedButton("Home", on_click=lambda _: self.page.go("/Home")),
                    ],
                    padding=0,
                )
            ) 
        elif self.page.route == "/Invoice_wholesale":
            self.layout=AppLayout(self,self.page,page_name="B2B")
            self.page.views.append(
                ft.View(
                    "/Invoice_wholesale",
                    appbar=self.layout.appbarpage,
                    controls=[
                        ft.Text("Invoice_wholesale"),
                        ft.ElevatedButton("Go to Log Out", on_click=lambda _: self.page.go("/")),
                        ft.ElevatedButton("Home", on_click=lambda _: self.page.go("/Home")),
                    ],
                )
            ) 
        elif self.page.route == "/profile":
            
            self.layout=AppLayout(self,self.page,page_name="profile")
            self.page.views.append(
                ft.View(
                    "/profile",
                    appbar=self.layout.appbarpage,
                    controls=[
                        # ft.Text("Profile section"),
                        self.layout,  
                        # ft.ElevatedButton("Go to Log Out", on_click=lambda _: self.page.go("/")),
                        # ft.ElevatedButton("Home", on_click=lambda _: self.page.go("/Home")),
                    ],padding=0,
                )
            ) 
        elif self.page.route == "/setting":
            self.layout=AppLayout(self,self.page,page_name="Setting")
            self.page.views.append(
                ft.View(
                    "/setting",
                    appbar=self.layout.appbarpage,
                    controls=[
                        ft.Text("Setting section"),
                        ft.ElevatedButton("Go to Log Out", on_click=lambda _: self.page.go("/")),
                        ft.ElevatedButton("Home", on_click=lambda _: self.page.go("/Home")),
                    ],
                )
            ) 
        elif self.page.route == "/Item_Management":
            self.layout=AppLayout(self,self.page,page_name="Item_Mangement")
            self.page.views.append(
                ft.View(
                    "/Item_Management",
                    appbar=self.layout.appbarpage,
                    controls=[
                        ft.Text("Item_Management"),
                        ft.ElevatedButton("Go to Log Out", on_click=lambda _: self.page.go("/")),
                        ft.ElevatedButton("Home", on_click=lambda _: self.page.go("/Home")),
                    ],
                )
            )  
        elif self.page.route == "/Transport_Detail":
            self.layout=AppLayout(self,self.page,page_name="Transport Detail")
            self.page.views.append(
                ft.View(
                    "/Transport_Detail",
                    appbar=self.layout.appbarpage,
                    controls=[
                        ft.Text("Transport_Detail"),
                        ft.ElevatedButton("Go to Log Out", on_click=lambda _: self.page.go("/")),
                        ft.ElevatedButton("Home", on_click=lambda _: self.page.go("/Home")),
                    ],
                )
            )
        elif self.page.route == "/Cust_Management":
            self.layout=AppLayout(self,self.page,page_name="Customer Mangement")
            self.page.views.append(
                ft.View(
                    "/Cust_Management",
                    appbar=self.layout.appbarpage,
                    controls=[
                        ft.Text("Customer_Management"),
                        ft.ElevatedButton("Go to Log Out", on_click=lambda _: self.page.go("/")),
                        ft.ElevatedButton("Home", on_click=lambda _: self.page.go("/Home")),
                    ],
                )
            ) 
        else:

            self.layout=AppLayout(self,self.page,page_name="default")
            self.page.views.append(
                ft.View(
                    "/default",
                    appbar=self.layout.appbarpage,
                    controls=[self.layout,
                        ft.Text("Default Page"),
                        ft.ElevatedButton("Go to Log In", on_click=lambda _: self.page.go("/")),
                    ],
                )
            )

        # Update the page with the new view
        self.page.update()
    def page_resize(self):
        """
        Updates the layout when the page is resized.
        """
        # self.active_view.on_resized(
        #     self.sidebar.visible, self.page.window_width, self.page.window_height
        # )
        self.page.update()
    def toggle_nav_rail(self, e):
        """
        Toggles the visibility of the sidebar.

        Args:
            e: The event instance.
        """
        print("Toggle nav rail triggered")
        self.sidebar.visible = not self.sidebar.visible
        print(f"Sidebar visibility: {self.sidebar.visible}")
        # self.toggle_nav_rail_button.selected = not self.toggle_nav_rail_button.selected
        self.layout.page_resize()
        self.page.update()



def main(page: Page):

    page.title = "Bill And Management "
    # page.padding = 0  # Ensure no padding on the page
    # page.spacing = 0  # No extra spacing between items
    page.theme = theme.Theme(font_family="Verdana")
    page.theme.page_transitions.windows = "cupertino"
    page.fonts = {
            "sonic": "assets/font/Freedom-10eM.ttf",
            "im_font": "assets/font/IMFellDoublePicaSC-Regular.ttf",
            "inflt": "assets/font/InflateptxBase-ax3da.ttf",
            "Pacifico": "Pacifico-Regular.ttf"
        }
    page.auto_scroll=False  
    page.scroll=ft.ScrollMode.ADAPTIVE
    page.adaptive=True
    page.bgcolor = colors.WHITE
    app = ShopMangement(page)#, InMemoryStore())
    page.add(app)
    page.update()
# it was run fine with old version of flet NOw

ft.app(target=main, assets_dir="../assets")